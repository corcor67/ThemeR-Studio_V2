#!/bin/bash -e
# ApkManager Launcher v1.0
# Created by CorCor67
# v1.0 Original build

gnome-terminal  --execute bash -c "cd /home/$USER/Android/ApkManager && /home/$USER/Android/ApkManager/Script.sh && exit ; bash"
exit 0 
